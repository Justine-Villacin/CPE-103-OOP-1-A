import json
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent / "lms_data"

def load_json(filename):
    with open(DATA_DIR / filename, "r") as f:
        return json.load(f)

def save_json(filename, data):
    with open(DATA_DIR / filename, "w") as f:
        json.dump(data, f, indent=4)

def get_courses():
    return load_json("courses.json")

def enroll_student(student_id, course_id):
    enrollments = load_json("enrollments.json")
    if student_id not in enrollments:
        enrollments[student_id] = []
    if course_id not in enrollments[student_id]:
        enrollments[student_id].append(course_id)
        save_json("enrollments.json", enrollments)
        return True
    return False

def get_enrolled_courses(student_id):
    enrollments = load_json("enrollments.json")
    return enrollments.get(student_id, [])

def get_assignments_for_student(student_id):
    assignments = load_json("assignments.json")
    enrolled = get_enrolled_courses(student_id)
    return {cid: assignments[cid] for cid in enrolled if cid in assignments}

def get_quizzes_for_student(student_id):
    quizzes = load_json("quizzes.json")
    enrolled = get_enrolled_courses(student_id)
    return {cid: quizzes[cid] for cid in enrolled if cid in quizzes}

def post_assignment(instructor, course_id, title, description):
    courses = load_json("courses.json")
    assignments = load_json("assignments.json")
    # Check instructor owns course
    for course in courses:
        if course["course_id"] == course_id and course["instructor"] == instructor:
            if course_id not in assignments:
                assignments[course_id] = []
            assignments[course_id].append({"title": title, "description": description})
            save_json("assignments.json", assignments)
            return True
    return False

def post_quiz(instructor, course_id, title, description):
    courses = load_json("courses.json")
    quizzes = load_json("quizzes.json")
    for course in courses:
        if course["course_id"] == course_id and course["instructor"] == instructor:
            if course_id not in quizzes:
                quizzes[course_id] = []
            quizzes[course_id].append({"title": title, "description": description})
            save_json("quizzes.json", quizzes)
            return True
    return False
