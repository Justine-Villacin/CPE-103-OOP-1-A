import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import os

current_user = "student"  # Change to "instructor" to see instructor dashboard

# Create main window
root = tk.Tk()
root.title("LMS Dashboard")
root.state("zoomed")
root.resizable(False, False)

# Get image path
base_path = os.path.dirname(os.path.dirname(__file__))
images_folder = os.path.join(base_path, "images")

# Load and resize images
logo_ucc = Image.open(os.path.join(images_folder, "UCC.png")).resize((60, 60))
logo_coe = Image.open(os.path.join(images_folder, "COE.png")).resize((60, 60))
logo_ls = Image.open(os.path.join(images_folder, "LS.png")).resize((110, 70))
background_img_original = Image.open(os.path.join(images_folder, "BLURED LOGO COENGG.png"))

logo_ucc = ImageTk.PhotoImage(logo_ucc)
logo_coe = ImageTk.PhotoImage(logo_coe)
logo_ls = ImageTk.PhotoImage(logo_ls)

# HEADER
header = tk.Frame(root, bg="#0077c2", height=80)
header.pack(fill="x", side="top")

tk.Label(header, image=logo_ucc, bg="#0077c2").pack(side="left", pady=10)
tk.Label(header, image=logo_coe, bg="#0077c2").pack(side="left", pady=10)
tk.Label(header, image=logo_ls, bg="#0077c2").pack(side="left", pady=10)

title = tk.Label(header, text=f"{current_user.title()} Dashboard", font=("Orbitron", 24, "bold"), bg="#0077c2", fg="black")
title.pack(side="left", padx=20)

# MAIN BODY
main_frame = tk.Frame(root)
main_frame.pack(fill="both", expand=True)

# Sidebar
sidebar = tk.Frame(main_frame, bg="#00bcd4", width=200)
sidebar.pack(side="left", fill="y")

# Content area
content_frame = tk.Frame(main_frame)
content_frame.pack(side="left", fill="both", expand=True)

# Label to hold the background image
bg_label = tk.Label(content_frame)
bg_label.place(relx=0.5, rely=0.5, anchor="center")

# Function to resize and place background
def resize_bg(event):
    width = event.width
    height = event.height
    resized = background_img_original.resize((width, height), Image.Resampling.LANCZOS)
    bg_image = ImageTk.PhotoImage(resized)
    bg_label.configure(image=bg_image)
    bg_label.image = bg_image  # Keep reference
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)

content_frame.bind("<Configure>", resize_bg)

# FRAME MANAGEMENT
frames = {}

def create_frame(name):
    f = tk.Frame(content_frame)
    frames[name] = f
    return f

# Student dashboard content
home_frame = create_frame("home")
courses_frame = create_frame("courses")
assignment_frame = create_frame("assignment")
quiz_frame = create_frame("quiz")

tk.Label(home_frame, text="Welcome to your LMS Dashboard!", font=("Orbitron", 18), fg="black").pack(pady=50)

tk.Label(courses_frame, text="Available Courses", font=("Orbitron", 18), fg="black").pack(pady=20)
courses = ["Math", "Programming", "Physics"]
for course in courses:
    course_row = tk.Frame(courses_frame)
    course_row.pack(pady=10)
    tk.Label(course_row, text=course, font=("Orbitron", 16), fg="black").pack(side="left", padx=10)
    tk.Button(course_row, text="Apply", bg="#4CAF50", fg="white").pack(side="left")

tk.Label(assignment_frame, text="Assignments", font=("Orbitron", 18), fg="black").pack(pady=20)
tk.Label(assignment_frame, text="No assignments added yet.", font=("Orbitron", 14), fg="gray").pack()

tk.Label(quiz_frame, text="Quizzes", font=("Orbitron", 18), fg="black").pack(pady=20)
tk.Label(quiz_frame, text="No quizzes added yet.", font=("Orbitron", 14), fg="gray").pack()

# Instructor dashboard content
post_assignment_frame = create_frame("post_assignment")
create_quiz_frame = create_frame("create_quiz")
manage_courses_frame = create_frame("manage_courses")

tk.Label(post_assignment_frame, text="Post a New Assignment", font=("Orbitron", 18), fg="black").pack(pady=50)
tk.Label(create_quiz_frame, text="Create a New Quiz", font=("Orbitron", 18), fg="black").pack(pady=50)
tk.Label(manage_courses_frame, text="Manage Courses", font=("Orbitron", 18), fg="black").pack(pady=50)

# ---------- FRAME SWITCHING ----------
def show_frame(name):
    for f in frames.values():
        f.place_forget()
    frames[name].place(relx=0.5, rely=0.5, anchor="center")

# Sidebar buttons
button_styles = {
    "font": ("Orbitron", 16, "bold"),
    "width": 15,
    "height": 2,
    "bd": 0,
    "relief": "flat",
}

if current_user == "student":
    tk.Button(sidebar, text="Home", bg="#00bcd4", fg="black", command=lambda: show_frame("home"), **button_styles).pack(pady=20)
    tk.Button(sidebar, text="Courses", bg="#00bcd4", fg="black", command=lambda: show_frame("courses"), **button_styles).pack(pady=20)
    tk.Button(sidebar, text="Assignment", bg="#00bcd4", fg="black", command=lambda: show_frame("assignment"), **button_styles).pack(pady=20)
    tk.Button(sidebar, text="Quiz", bg="#00bcd4", fg="black", command=lambda: show_frame("quiz"), **button_styles).pack(pady=20)
    show_frame("home")

elif current_user == "instructor":
    tk.Button(sidebar, text="Post Assignment", bg="#0077c2", fg="black", command=lambda: show_frame("post_assignment"), **button_styles).pack(pady=20)
    tk.Button(sidebar, text="Create Quiz", bg="#00bcd4", fg="black", command=lambda: show_frame("create_quiz"), **button_styles).pack(pady=20)
    tk.Button(sidebar, text="Manage Courses", bg="#4dd0e1", fg="black", command=lambda: show_frame("manage_courses"), **button_styles).pack(pady=20)
    show_frame("post_assignment")

root.mainloop()